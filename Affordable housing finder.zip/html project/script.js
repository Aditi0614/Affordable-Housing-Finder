const housingData = [
    { location: "New York", price: 1000, description: "1 Bedroom apartment in New York" },
    { location: "Los Angeles", price: 1200, description: "2 Bedroom apartment in LA" },
    { location: "Chicago", price: 900, description: "Studio apartment in Chicago" },
    { location: "Houston", price: 800, description: "Affordable housing in Houston" },
    { location: "Miami", price: 1100, description: "1 Bedroom apartment in Miami" }
];

// Function to render results
function renderResults(results) {
    const resultsContainer = document.getElementById("resultsContainer");
    resultsContainer.innerHTML = "";

    if (results.length === 0) {
        resultsContainer.innerHTML = "<p>No results found</p>";
    } else {
        results.forEach(item => {
            const resultItem = document.createElement("div");
            resultItem.classList.add("result-item");

            resultItem.innerHTML = `
                <h3>${item.location}</h3>
                <p>Price: $${item.price}/month</p>
                <p>${item.description}</p>
            `;
            resultsContainer.appendChild(resultItem);
        });
    }
}

// Function to handle search
function handleSearch(event) {
    event.preventDefault();

    const locationInput = document.getElementById("locationInput").value.toLowerCase();
    const priceInput = parseInt(document.getElementById("priceInput").value);

    const filteredResults = housingData.filter(item => 
        item.location.toLowerCase().includes(locationInput) && item.price <= priceInput
    );

    renderResults(filteredResults);
}

// Add event listener to the form
document.getElementById("searchForm").addEventListener("submit", handleSearch);